import DirectorCameraScreen from "@/src/camera/DirectorCameraScreen";

export default function Home() {
  return <DirectorCameraScreen />;
}
