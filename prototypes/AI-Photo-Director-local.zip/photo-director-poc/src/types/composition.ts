export interface DetectedSubject { centerX: number; centerY: number; width: number; height: number; confidence?: number }
export type FramingMode = "AUTO" | "CLOSE_UP" | "WAIST_UP" | "FULL_BODY";
export interface BodyObservation {
  centerX: number; centerY: number; width: number; height: number;
  shouldersVisible: boolean; hipsVisible: boolean; kneesVisible: boolean; anklesVisible: boolean;
  top: number; bottom: number; left: number; right: number;
}
export interface SceneObservation { face: DetectedSubject | null; body: BodyObservation | null; faceCount: number }
export type GuidanceType = "MOVE_LEFT" | "MOVE_RIGHT" | "MOVE_UP" | "MOVE_DOWN" | "MOVE_CLOSER" | "MOVE_BACK" | "READY" | "NO_SUBJECT";
export interface CompositionGuidance { type: GuidanceType; message: string; severity: number; reason?: string }
