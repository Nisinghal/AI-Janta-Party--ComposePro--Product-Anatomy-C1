import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Check, ScanFace, ZoomIn, ZoomOut } from "lucide-react";
import type { CompositionGuidance } from "../types/composition";
export default function GuidancePill({ guidance }: { guidance: CompositionGuidance }) {
  const icons = { MOVE_LEFT: ArrowLeft, MOVE_RIGHT: ArrowRight, MOVE_UP: ArrowUp, MOVE_DOWN: ArrowDown, MOVE_CLOSER: ZoomIn, MOVE_BACK: ZoomOut, READY: Check, NO_SUBJECT: ScanFace };
  const Icon = icons[guidance.type];
  return <div className={`guidance-pill ${guidance.type === "READY" ? "is-ready" : ""}`} aria-live="polite"><Icon size={21} strokeWidth={2.2} aria-hidden /><span><strong>{guidance.message}</strong>{guidance.reason && <small>{guidance.reason}</small>}</span></div>;
}
