import type { FramingMode } from "../types/composition";
export default function SubjectTargetZone({ ready, mode }: { ready: boolean; mode: Exclude<FramingMode,"AUTO"> }) { return <div className={`target-zone ${mode.toLowerCase()} ${ready ? "is-ready" : ""}`} aria-hidden><span /><span /><span /><span /></div>; }
